#include "editor/editor.hpp"
#include <unistd.h>
int main(int argc, char* argv[]) {
  editor::Editor edi;

  if (argc >= 2) {
    edi.run(argv[1]);
  }
  else {
    edi.run();
  }
  return 0;
}
