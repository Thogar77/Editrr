#pragma once
#include <unordered_map>
#include "editor/key_mappings.hpp"

static constexpr int TABSTOP = 8;
static constexpr int QUIT_TIMES = 3;
enum class Highlight : uint8_t {
    Normal = 0,
    Number,
    Match,
    String,
    Comment,
    Keyword1,
    Keyword2,
};
struct EditorSyntax {
    const char* filetype;
    const char** filematch;   // list of extensions/patterns, terminated nullptr
    const char** keywords;    // list of keywords, terminated nullptr
    const char* singleline_comment_start; // "//"
    const char* multiline_comment_start;  // "/*"
    const char* multiline_comment_end;    // "*/"
};
static const char* C_HL_extensions[] = { ".c", ".h", ".cpp", ".hpp", nullptr };

// keywordy: te z sufiksem '|' będą Keyword2
static const char* C_HL_keywords[] = {
    // Keyword1
    "switch", "if", "while", "for", "break", "continue", "return", "else",
    "struct", "union", "typedef", "static", "enum", "class", "case",
    // Keyword2 (types) -> zakończone '|'
    "int|", "long|", "double|", "float|", "char|", "unsigned|", "signed|",
    "void|", "bool|", "size_t|", "std|",
    nullptr
};

static const EditorSyntax HLDB[] = {
  {
    "c/cpp",
    C_HL_extensions,
    C_HL_keywords,
    "//",
    "/*",
    "*/"
  }
};

static const size_t HLDB_ENTRIES = sizeof(HLDB) / sizeof(HLDB[0]);

namespace editor {
    struct EditorConfig {
        std::unordered_map<char, KeyAction> keymap = {
            {'h', cursor::Action::MoveLeft},
            {'l', cursor::Action::MoveRight},
            {'k', cursor::Action::MoveUp},
            {'j', cursor::Action::MoveDown},
            {editor::ARROW_UP, cursor::Action::MoveUp},
            {editor::ARROW_DOWN, cursor::Action::MoveDown},
            {editor::ARROW_RIGHT, cursor::Action::MoveRight},
            {editor::ARROW_LEFT, cursor::Action::MoveLeft},
            {HOME_KEY,  cursor::Action::MoveHome},
            {END_KEY,   cursor::Action::MoveEnd},
            {PAGE_UP,   cursor::Action::MovePageUp},
            {PAGE_DOWN, cursor::Action::MovePageDown},
        };
    };


}