#pragma once
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/ioctl.h>
#include <termios.h>
#include <unistd.h>
#include <string>
#include <optional>

#include <vector>
#include <fstream>
#include <ctime>
#include <cstdio>
#include <cstdarg>
#include <cerrno>
#include <sys/stat.h>
#include <cstring>
#include <fcntl.h>
#include <functional>

#include "editor/key_mappings.hpp"
#include "editor/config.hpp"
#include "terminal/terminal.hpp"
#include "editor/utils.hpp"
struct Cursor {
  int x;
  int y;
  int rx{ 0 };
};
struct Row {
  std::string chars;
  std::string render;
  int size() const { return static_cast<int>(chars.size()); }
  std::vector<Highlight> hl;
  bool hl_open_comment = false;
};

struct Buffer {
  std::vector<Row> rows;

  int numrows() const { return static_cast<int>(rows.size()); }
};
namespace editor {

  class Editor {
  public:
    Editor();
    void run(const std::string& path = {});
    void enable_raw_mode();
    void restore();

  private:
    EditorConfig config_;
    Cursor cursor;
    Terminal term;
    Buffer buffer_;
    int width_;
    int height_;
    int rowoff_{ 0 };
    int coloff_{ 0 };
    bool dirty_{ false };
    std::string filename_;
    int saved_hl_line_ = -1;
    std::vector<Highlight> saved_hl_;
    std::string statusmsg_;
    std::time_t statusmsg_time_ = 0;
    const EditorSyntax* syntax_ = nullptr;
    int find_last_match_ = -1;
    int find_direction_ = 1;

    void initialize();
    int read_key();
    void scroll();
    void process_keypress();
    void update_syntax(int row_index);
    void update_syntax_from_(int start);
    void clamp_cursor();
    void refresh_screen();
    void update_row(Row& row);
    void update_row(int idx);
    void open_file(const std::string& path);
    int cx_to_rx_(const Row& row, int cx) const;
    int rx_to_cx_(const Row& row, int rx) const;
    void clear_screen();
    void move_cursor(const char& key);
    void draw_rows(std::string& buffer);
    void draw_status_bar(std::string& out);
    int get_window_size(int& rows, int& cols);
    int get_cursor_position(int& rows, int& cols);
    void row_del_char(Row& row, int at);
    void row_append_string(Row& row, const std::string& s);
    std::optional<std::string> prompt(const char* prompt_fmt);
    std::optional<std::string> prompt(
      const char* prompt_fmt,
      const std::function<void(const std::string&, int)>& callback);
    void del_char();
    void del_row(int at);
    std::string rows_to_string() const;
    void find();
    void find_callback_(const std::string& query, int key);
    void save_to_disk();
    void clear_saved_hl_();
    void set_status_message(const char* fmt, ...);
    void row_insert_char(Row& row, int at, char c);
    void insert_newline();
    void select_syntax_highlight_();
    void insert_char(int c);
    void insert_row(int at, const std::string& s);
    void draw_message_bar(std::string& out);
    void dispatch_action(const ::KeyAction& action);
    void handle_cursor_action(const cursor::Action& action);
    void die(const std::string error_code);
  };
}