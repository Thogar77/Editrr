#pragma once
#include <variant>
#define CTRL_KEY(k) ((k) & 0x1f)

namespace cursor {
    enum class Action {
        MoveLeft,
        MoveRight,
        MoveUp,
        MoveDown,
        MovePageUp,
        MovePageDown,
        MoveHome,
        MoveEnd
    };
}

namespace editor {
    enum class Action {
        Quit
    };
    enum KeyCode : int {
        KEY_ESC = 27,

        // wartości > 255 żeby nie kolidować ze zwykłymi charami
        ARROW_LEFT = 1000,
        ARROW_RIGHT = 1001,
        ARROW_UP = 1002,
        ARROW_DOWN = 1003,
        PAGE_UP = 1004,
        PAGE_DOWN = 1005,
        HOME_KEY = 1006,
        END_KEY = 1007,
        DELETE_KEY = 1008,
        BACKSPACE = 127,
        ENTER = '\r'
    };
}

using KeyAction = std::variant<cursor::Action
    , editor::Action
>;

